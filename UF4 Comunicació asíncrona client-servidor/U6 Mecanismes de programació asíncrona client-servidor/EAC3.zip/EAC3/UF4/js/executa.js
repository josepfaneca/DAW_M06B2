window.onload = function() {
    if (window.XMLHttpRequest) {
        httpRequest = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        httpRequest = new ActiveXObject("Microsoft.XMLHTTP");
    } else {
        console.error("Error: Aquest navegador no admet AJAX.");
    }

    httpRequest.onload = processarResposta;
    httpRequest.open('GET', 'provincies2.xml', true)
    httpRequest.send(null);

    function processarResposta() {
        var elementArrel = httpRequest.responseXML.documentElement;
        var elements = elementArrel.childNodes;
        var llista = document.createElement('ul');

        for (var i = 0; i < elements.length; i++) {
            if (elements[i].nodeType == Node.ELEMENT_NODE) {
                var item = processarElement(elements[i]);
                llista.appendChild(item);
            }
        }

        document.body.appendChild(llista);
    }

    function processarElement(element) {
        var codiPostal = element.getAttribute('cp');
        var provincia = element.textContent;
        var item = document.createElement('li');
        item.textContent = provincia + ' (CP ' + codiPostal + ')';
        return item;
    }

}