window.onload = function() {

    var imatgeIoc = document.getElementById("imatge"),
        botoBuidar = document.getElementById("buidar"),
        contadorRoig = 0,
        contadorBlau = 0,
        contadorVerd = 0,
        contadorTaronja = 0,
        contadorRegistre = 0,
        registreEvents = "",
        clickCount = 0;

    function mostraMissatge(e) {
        console.log(e);
        alert('Detectat un event de tipus: ' + e.type + " i amb wich " + e.which);
    }

    function validarContador(contador, numero) {
        if (contador > 99 || contador < 0) {
            switch (numero) {
                case 1:
                    contadorRoig = 0;
                    break;
                case 2:
                    contadorBlau = 0;
                    break;
                case 3:
                    contadorVerd = 0;
                    break;
                default:
                    contadorTaronja = 0;
                    break;
            }
            return 0;
        } else {
            return contador;
        }
    }

    function singleClick() {
        contadorRoig++;
        console.log("single click");
        document.getElementById("un").innerHTML = validarContador(contadorRoig, 1);

    }

    function doubleClick() {
        contadorBlau++;
        console.log("double click");
        document.getElementById("dos").innerHTML = validarContador(contadorBlau, 2);
    }

    //extret d'StackOverflow
    imatgeIoc.addEventListener('click', function() {
        clickCount++;
        if (clickCount === 1) {
            singleClickTimer = setTimeout(function() {
                clickCount = 0;
                singleClick();
            }, 400);
        } else if (clickCount === 2) {
            clearTimeout(singleClickTimer);
            clickCount = 0;
            doubleClick();
        }
    }, false);

    //deshabilitar el menú contextual del botó dret
    imatgeIoc.addEventListener('contextmenu', function(e) {
        e.preventDefault()
    });

    imatgeIoc.onmousedown = function(e) {

        //coordenada X de la imatge (utilitzo l'atribut offsetX)
        document.getElementById("sis").innerHTML = e.offsetX + 6 //valor del border;
        if (e.which == 3) {
            contadorRoig--;
            document.getElementById("un").innerHTML = validarContador(contadorRoig, 1);
        }
    }

    //comptar quantes vegades entra a la imatge
    imatgeIoc.onmouseenter = function(e) {
        console.log("S'ha disparat l'event: " + e.type);
        contadorVerd++;
        document.getElementById("tres").innerHTML = validarContador(contadorVerd, 3);
    }

    //comptar quantes vegades surt de la imatge
    imatgeIoc.onmouseleave = function() {
        contadorTaronja++;
        document.getElementById("quatre").innerHTML = validarContador(contadorTaronja, 4);
    }

    //determinar tecla
    document.onkeypress = mostrarInformacioCaracter;

    function mostrarInformacioCaracter(evObject) {
        var tecla = evObject.key || evObject.keyIdentifier;
        document.getElementById("cinc").innerHTML = tecla;
    }

    //notificar events
    imatgeIoc.addEventListener('mouseenter', notificaObservador);
    imatgeIoc.addEventListener('mouseleave', notificaObservador);
    imatgeIoc.addEventListener('mousemove', notificaObservador);
    imatgeIoc.addEventListener('mouseout', notificaObservador);
    imatgeIoc.addEventListener('mouseover', notificaObservador);
    imatgeIoc.addEventListener('click', notificaObservador);
    imatgeIoc.addEventListener('contextmenu', notificaObservador);
    imatgeIoc.addEventListener('mouseup', notificaObservador);
    imatgeIoc.addEventListener('mousedown', notificaObservador);


    function notificaObservador(e) {
        contadorRegistre++;
        console.log("S'ha disparat un event de tipus: ", e.type);
        var aux = e.type + " ";
        registreEvents = registreEvents + aux;
        if (contadorRegistre == 3) {
            console.log("ELS 3 EVENTS SÓN: ", registreEvents);
            document.getElementById("missatges").innerHTML = registreEvents;
            contadorRegistre = 0;
            registreEvents = "";
        }
    }

    botoBuidar.addEventListener('click', buidarRegistre);

    function buidarRegistre() {
        registreEvents = "";
        document.getElementById("missatges").innerHTML = registreEvents;
    }

}