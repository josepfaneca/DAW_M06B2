window.onload=function(){
    //Seleccionem els diferents elements del DOM
    var imatge = document.getElementById("imatge");
    var un = document.getElementById("un");
    var dos = document.getElementById("dos");
    var tres = document.getElementById("tres");
    var quatre = document.getElementById("quatre");
    var cinc = document.getElementById("cinc");
    var sis = document.getElementById("sis");
    var boto = document.getElementById("buidar");
    var esdeveniments = document.getElementById("missatges");

    //Variables per comptadors
    var comptVermell =0;
    var comptBlau =0;
    var comptVerd =0;
    var comptTaronja =0;

    //Assignar events
    imatge.addEventListener("click",manegament);
    imatge.addEventListener("contextmenu",manegament);
    imatge.addEventListener("dblclick",manegament);
    imatge.addEventListener("mouseenter",manegament);
    imatge.addEventListener("mouseleave",manegament);
    document.addEventListener("keypress", manegament);


    function manegament(esd){
        switch(esd.type){
            case 'click':
                if(comptVermell<99){
                    comptVermell++;
                    un.textContent = comptVermell;
                }
                sis.textContent = event.offsetX;

            break;

            case 'contextmenu':
                event.preventDefault();
                if(comptVermell>0){
                    comptVermell--;
                    un.textContent = comptVermell;
                }
            break;

            case 'dblclick':
                if(comptBlau<99){
                    comptBlau++;
                    dos.textContent = comptBlau;
                }
            break;

            case 'mouseenter':
                if(comptVerd<99){
                    comptVerd++;
                    tres.textContent = comptVerd;
                }
            break;

            case 'mouseleave':
                if(comptTaronja<99){
                    comptTaronja++;
                    quatre.textContent = comptTaronja;
                }
            break;

            case 'keypress':
                cinc.textContent = event.key;
            break;
        }

        esdeveniments.textContent += esd.type + " ";
    };

    buidar.addEventListener("click",function(){
        //Reiniciem comptadors
        comptVermell =0;
        comptBlau =0;
        comptVerd =0;
        comptTaronja =0;

        //Buidem camps
        un.textContent = 0;
        dos.textContent = 0;
        tres.textContent = 0;
        quatre.textContent = 0;
        cinc.textContent = "~";
        sis.textContent = 0;
        esdeveniments.textContent = "";
    })
    
}