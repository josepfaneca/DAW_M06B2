$(document).ready(function() {
    // Apartat 1 (amb jQuery)
    mostrarOcultarIcones();

    // Apartat 2 (sense jQuery)
    eliminarCarta();

    // Apartat 3 (amb jQuery)
    moureCarta();

    // Apartat 4 (sense jQuery)
    jugarCarta();

    // Apartat 5 (amb jQuery)
    $('#cartes-ma').next().on('click', function() {
        $('#formulari').show();
    });

    $('#formulari').find('.cancel').on('click', function() {
        $('#formulari').hide();
    });

    // Apartat 6 (amb jQuery)
    $('#formulari').find('.btn').eq(0).on('click', function(e) {
        e.preventDefault();
        afegeixCarta();
    });
});

// Apartat 1 (amb jQuery)
function mostrarOcultarIcones() {
    // Amaguem les icones inicialment
    $('#cartes-ma').find('.opcions').hide();
    // Afegim l'esdeveniment per quan entri el ratolí en la carta
    $('#cartes-ma').find('.carta').on('mouseenter', function() {
        $(this).find('.opcions').show();
    });
    // Afegim l'esdeveniment per quan surti el ratolí de la carta
    $('#cartes-ma').find('.carta').on('mouseleave', function() {
        $(this).find('.opcions').hide();
    });
}

// Apartat 2 (sense jQuery)
function eliminarCarta() {

    var cartes = document.getElementById('cartes-ma').children;

    for (let i = 0; i < cartes.length; i++) {
        var botoEliminar = cartes[i].firstElementChild.firstElementChild.firstElementChild.lastElementChild;
        botoEliminar.addEventListener('click', function() {
            this.parentNode.parentNode.parentNode.parentNode.remove();
        });
    }
}

// Apartat 3 (amb jQuery)
function moureCarta() {
    // Clic sobre la fletxa cap a la dreta
    $('#cartes-ma').find('.fa-arrow-right').on('click', function() {
        $carta = $(this).parents('.carta');
        $carta.insertAfter($carta.next());
    });
    // Clic sobre la fletxa cap a l'esquerra
    $('#cartes-ma').find('.fa-arrow-left').on('click', function() {
        $carta = $(this).parents('.carta');
        $carta.insertBefore($carta.prev());
    });

}

// Apartat 4 (sense jQuery)
function jugarCarta() {
    var cartes = document.getElementById('cartes-ma').children;

    for (let i = 0; i < cartes.length; i++) {
        // Cerquem el botót de jugar de cada carta
        botoJugar = cartes[i].firstElementChild.firstElementChild.firstElementChild.firstElementChild;

        // Afegim l'esdeveniment de clic al botó de jugar
        botoJugar.addEventListener('click', function() {
            //Obtenim la informació de la carta sobre la que s'ha clicat el botó
            //Aquí 'this' fa referència al botó de jugar de la carta corresponent
            var contingutCarta = this.parentNode.nextElementSibling;
            var nomCarta = contingutCarta.firstElementChild.innerText;
            var imatgeCarta = contingutCarta.nextElementSibling.getAttribute('src');
            var colorCarta = contingutCarta.parentNode.parentNode.parentNode.getAttribute('color');
            var batalla = contingutCarta.parentNode.getElementsByClassName('batalla');
            if (batalla.length > 0) {
                var atac = batalla[0].firstElementChild.textContent;
                var defensa = batalla[0].lastElementChild.textContent;
            }

            //Creem la nova carta en el terreny de joc
            var divInicial = document.createElement('div');
            divInicial.className += "carta-jugada";
            divInicial.style = 'background-color:' + colorCarta;
            var spanNom = document.createElement('span');
            spanNom.textContent = nomCarta;
            var imatge = document.createElement('img');
            imatge.src = imatgeCarta;
            divInicial.appendChild(spanNom);
            divInicial.appendChild(imatge);

            if (batalla.length > 0) {
                var paragraf = document.createElement('p');
                var spanPower = document.createElement('span');
                var spanToughness = document.createElement('span');
                spanPower.textContent = atac;
                spanToughness.textContent = defensa;
                paragraf.appendChild(spanPower);
                paragraf.textContent += '/';
                paragraf.appendChild(spanToughness);
                divInicial.appendChild(paragraf);
            }

            var terreny = document.getElementById('terreny-joc');
            terreny.appendChild(divInicial);
        });
    }
}

// Apartat 6 (amb jQuery)
function afegeixCarta() {
    var nom = $('#nom').val();
    var mana = transformar_text($('#mana').val());
    var color = $('#color').val();
    var imatge = $('#imat').val();
    var tipus = $('#tipus').val();
    var descripcio = $('#desc').val();
    var atac = $('#atac').val();
    var defensa = $('#defensa').val();

    if (nom != '' && imatge != '' && tipus != '' && descripcio != '') {


        $divPrincipal = $(`<div class="carta" color="` + color + `">   
      <div class="fons-carta">

        <div class="card-frame">
          <div class="opcions">
            <span class="fas fa-dice"></span>
            <span class="fas fa-arrow-right"></span>
            <span class="fas fa-arrow-left"></span>
            <span class="fas fa-trash-alt"></span>
          </div>

          <div class="contingut-carta">
            <h1 class="nom"> ` + nom + `</h1>
            <div class="mana">` + mana + `</div>
          </div>

          <img class="imatge-carta" src="` + imatge + `" alt="nissa art">

          <div class="tipus-carta">
            <h1 class="type">` + tipus + `</h1>
          </div>

          <div class="text-carta">
            <p class="descripcio marge-intern">` + descripcio + `</p>
          </div>

        </div>

      </div>

    </div>`);

        if (atac != '' && defensa != '') {

            $divAtacDefensa = $(`<div class="informacio-inferior marge-dintre">
          <div class="batalla">
            <span class="power">` + atac + `</span>
            /
            <span class="toughness">` + defensa + `</span>
          </div>
        </div>`);

            $divPrincipal.find('.card-frame').append($divAtacDefensa);
        }

        //Afegim els esdeveniments a la nova carta
        $divPrincipal.find('.opcions').hide()
        $divPrincipal.on('mouseenter', function() {
            $(this).find('.opcions').show();
        });
        $divPrincipal.on('mouseleave', function() {
            $(this).find('.opcions').hide();
        });

        $divPrincipal.find('.fa-arrow-right').on('click', function() {
            $carta = $(this).parents('.carta');
            $carta.insertAfter($carta.next());
        });

        $divPrincipal.find('.fa-arrow-left').on('click', function() {
            $carta = $(this).parents('.carta');
            $carta.insertBefore($carta.prev());
        });

        $divPrincipal.find('.fa-trash-alt').on('click', function() {
            $(this).parents('.carta').remove();
        });

        $divPrincipal.find('.fa-dice').on('click', function() {
            $cartaTerrenyJoc = $(`<div class="carta-jugada" style="background-color:` + color + `">
        <span>` + nom + `</span>
        <img src="` + imatge + `">
      </div>`);

            if (atac != '' && defensa != '') {
                $cartaTerrenyAtac = $(`<p>
          <span>` + atac + `</span>
          /
          <span>` + defensa + `</span>
        </p>`);
                $cartaTerrenyJoc.append($cartaTerrenyAtac);
            }
            $('#terreny-joc').append($cartaTerrenyJoc);
        });

        // Afegim la carta creada a la ma
        $('#cartes-ma').append($divPrincipal);
        // Amaguem el formulari (opcional)
        $('#formulari').hide();
    }
}

//Funció que venia en el fitxer JS inicial
function transformar_text(text_simbols) {
    //Convertim els salts de línia a format HTML
    text_transformat = text_simbols.replace(/\r?\n/g, "<br />");
    //Cerquem el text a transformar
    var trobar = /\{[A-Z0-9/]*\}/g;
    //Canviem el text per les imatges corresponents
    var text_transformat = text_transformat.replace(trobar, function(x) {
        //Afagem el text de dintre de les {} treient les / interiors (si hi ha alguna)
        var lletres = x.substring(1, x.length - 1).replace('/', '');
        return "<img src='https://c2.scryfall.com/file/scryfall-symbols/card-symbols/" + lletres + ".svg' class='mana-icon'>"
    });
    return text_transformat;
}