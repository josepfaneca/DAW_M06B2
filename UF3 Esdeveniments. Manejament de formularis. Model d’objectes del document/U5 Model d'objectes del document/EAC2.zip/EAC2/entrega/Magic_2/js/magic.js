window.onload = function() {

    function transformar_text(text_simbols) {
        //Convertim els salts de línia a format HTML
        text_transformat = text_simbols.replace(/\r?\n/g, "<br />");
        //Cerquem el text a transformar
        var trobar = /\{[A-Z0-9/]*\}/g;
        //Canviem el text per les imatges corresponents
        var text_transformat = text_transformat.replace(trobar, function(x) {
            //Afagem el text de dintre de les {} treient les / interiors (si hi ha alguna)
            var lletres = x.substring(1, x.length - 1).replace('/', '');
            return "<img src='https://c2.scryfall.com/file/scryfall-symbols/card-symbols/" + lletres + ".svg' id='mana-icon'>"
        });
        return text_transformat;
    }

    var eliminarCarta = function() {
        console.log(this.parentNode.parentNode.parentNode.parentNode.nodeName);
    }

    var cubellBasura = document.getElementsByClassName('fas fa-trash-alt');

    for (var i = 0; i < cubellBasura.length; i++) {
        cubellBasura[i].addEventListener('click', eliminarCarta);
    }


}