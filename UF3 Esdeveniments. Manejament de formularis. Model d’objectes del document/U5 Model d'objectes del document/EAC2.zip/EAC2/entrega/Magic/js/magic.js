$(document).ready(function() {

    function transformar_text(text_simbols) {
        //Convertim els salts de línia a format HTML
        text_transformat = text_simbols.replace(/\r?\n/g, "<br />");
        //Cerquem el text a transformar
        var trobar = /\{[A-Z0-9/]*\}/g;
        //Canviem el text per les imatges corresponents
        var text_transformat = text_transformat.replace(trobar, function(x) {
            //Afagem el text de dintre de les {} treient les / interiors (si hi ha alguna)
            var lletres = x.substring(1, x.length - 1).replace('/', '');
            return "<img src='https://c2.scryfall.com/file/scryfall-symbols/card-symbols/" + lletres + ".svg' class='mana-icon'>"
        });
        return text_transformat;
    }

    //Selectors
    var paperera = document.getElementsByClassName('fas fa-trash-alt');
    var jugarCarta = document.getElementsByClassName('fas fa-dice');
    var $carta = $('.carta');
    $('.opcions').hide();
    var $esquerra = $('span.fas.fa-arrow-left'); //botó dret
    var $dreta = $('span.fas.fa-arrow-right'); //botó esquerra
    var $botoCarta = $('.boto-carta');
    var $botoTanca = $('.btn.cancel');
    var $contenidor = $('#cartes-ma');

    //funció per eliminar una carta
    var eliminarCarta = function() {
        console.log(this.parentNode.parentNode.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode.parentNode.parentNode));
    }


    //funció per crear carta al tapet
    var afegirCartaTapet = function() {
        var terrenyJoc = document.getElementById("terreny-joc");
        var element1 = document.createElement('div');

        //color
        element1.className = "carta-jugada";
        var color = this.parentNode.parentNode.parentNode.parentNode.getAttribute('color');
        element1.style.backgroundColor = color;
        terrenyJoc.appendChild(element1);

        //nom    
        var dateSpan = document.createElement('span');
        var nomCarta = this.parentNode.parentNode.parentNode.parentNode.querySelector('.nom').textContent;
        dateSpan.style.display = "inline-block"; //estil per centrar el nom de les cartes 
        dateSpan.innerText = nomCarta;
        element1.appendChild(dateSpan);

        //imatge
        var img = document.createElement('img');
        var srcImg = this.parentNode.parentNode.parentNode.parentNode.querySelector('.imatge-carta').getAttribute('src');
        img.src = srcImg;
        element1.appendChild(img);

        //Si la carta sencera té valors d’atac
        var batalla = this.parentNode.parentNode.parentNode.parentNode.querySelector('.batalla');
        if (typeof(batalla) != 'undefined' && batalla != null) {
            var paragraf = document.createElement('p');
            element1.appendChild(paragraf);

            var dateSpan2 = document.createElement('span');
            var forca = this.parentNode.parentNode.parentNode.parentNode.querySelector('.power').textContent;
            dateSpan2.innerHTML = forca;
            paragraf.appendChild(dateSpan2);

            var text = document.createTextNode(" / ");
            paragraf.appendChild(text);

            var dateSpan3 = document.createElement('span');
            var resistencia = this.parentNode.parentNode.parentNode.parentNode.querySelector('.toughness').textContent;
            dateSpan3.innerHTML = resistencia;
            paragraf.appendChild(dateSpan3);

        } else {
            console.log("No existeix element batalla");
        }

    }

    //Afegir events

    for (var i = 0; i < paperera.length; i++) {
        paperera[i].addEventListener('click', eliminarCarta);
    }

    for (var i = 0; i < jugarCarta.length; i++) {
        jugarCarta[i].addEventListener('click', afegirCartaTapet);
    }

    //Mostrar i amagar les opcions de les cartes

    $carta.on('mouseenter', function() {
        var $opcions = $(this).find('.opcions'); //amago sols la carta on entro, no totes
        $opcions.show();
        //$('.opcions').show();
    })

    $carta.on('mouseleave', function() {
        $('.opcions').hide();
    })

    //Moure les cartes a dreta i a esquerra
    //Fonts:https://stackoverflow.com/questions/11183401/jquery-change-the-element-order
    //https://api.jquery.com/insertbefore/

    $esquerra.click(function() {
        var $cartaMoure = this.parentNode.parentNode.parentNode.parentNode;
        $($cartaMoure).insertBefore($($cartaMoure).prev($cartaMoure));
    })

    $dreta.click(function() {
        var $cartaMoure = this.parentNode.parentNode.parentNode.parentNode;
        $($cartaMoure).insertAfter($($cartaMoure).next($cartaMoure));
    })


    //es faci visible el formulari i s'amagui
    $botoCarta.click(function() {
        $('#formulari').show()
    })


    $botoTanca.click(function() {
        $('#formulari').hide()
    })

    //Font: https://api.jquery.com/submit-selector/

    var $botoForm = $('button[type="submit"]');

    $botoForm.click(function(event) {
        event.preventDefault();
        console.log("default " + event.type + " prevented");

        //Dades del formulari
        var colorCarta = $("#color").val();
        var nomCarta = $('input[name="nom"]').val();
        var tipusCarta = $('input[name="tipus"]').val();
        var Url = $('input[name="imat"]').val();
        var descripcio = $('input[name="desc"]').val();
        var atac = $('input[name="atac"]').val();
        var defensa = $('input[name="defensa"]').val();
        var mana = $('input[name="mana"]').val();

        //Elements DOM

        var $div = $('<div>');
        var $divFonsCarta = $('<div>');
        var $cardFrame = $('<div>');
        var $opcions = $('<div>');
        var $contingutCarta = $('<div>');
        var $nom = $('<h1 class="nom">');
        var $divMana = $('<div>');
        var imatgesMana = transformar_text(mana);
        var $imatgeCarta = $('<img class="imatge-carta" src=' + Url + ' alt="nissa art">')
        var $tipusCarta = $('<div>');
        var $textCarta = $('<div>');
        var $forcaResis = $('<div>');
        var $batalla = $('<div>');
        var $tipus = $('<h1 class="type">');
        var $descripcioIntern = $('<p class="descripcio marge-intern">');


        //var $tipusCartanom = $('<h1 class="type">');


        //Afegir classes
        $div.addClass('carta');
        $divFonsCarta.addClass('fons-carta');
        $cardFrame.addClass('card-frame');
        $opcions.addClass('opcions');
        $contingutCarta.addClass('contingut-carta');
        $divMana.addClass('mana');
        $tipusCarta.addClass('tipus-carta');
        $textCarta.addClass('text-carta');
        $forcaResis.addClass('informacio-inferior marge-dintre');
        $batalla.addClass('batalla');

        //$nom.addClass('nom');


        //Afegir els elements al DOM
        $div.attr('color', colorCarta);
        //$opcions.hide(); //style=display: none;
        $nom.text(nomCarta); //afegir nom
        $tipus.text(tipusCarta) //afegir tipus de carta
        $descripcioIntern.text(descripcio) //afegir text descripció del formulari


        $opcions.append('<span class="fas fa-dice"></span>');
        $opcions.append('<span class="fas fa-arrow-right"></span>');
        $opcions.append('<span class="fas fa-arrow-left"></span>');
        $opcions.append('<span class="fas fa-trash-alt"></span>');

        $cardFrame.append($opcions);
        $contingutCarta.append($nom);

        $divMana.prepend(imatgesMana);
        $contingutCarta.append($divMana);
        $tipusCarta.append($tipus); //revisar
        $textCarta.append($descripcioIntern); //revisar

        $batalla.append('<span class="power">' + atac + '</span>' + "  /  ");
        $batalla.append('<span class="toughness">' + defensa + '</span>');
        $forcaResis.append($batalla);

        $cardFrame.append($contingutCarta);
        $cardFrame.append($imatgeCarta);
        $cardFrame.append($tipusCarta);
        $cardFrame.append($textCarta);
        $cardFrame.append($forcaResis);

        $divFonsCarta.append($cardFrame);
        $div.append($divFonsCarta);
        $contenidor.append($div);

        //afegir els events
        $div.on('mouseenter', function() {
            var $opcions = $(this).find('.opcions');
            $opcions.show();
            //$('.opcions').show();
        });
        $div.on('mouseleave', function() {
            $('.opcions').hide();
        });

        var $basura = $opcions.children('span.fas.fa-trash-alt');
        var $afegirCartaTapet = $opcions.children('span.fas.fa-dice');

        //botó paperera
        $basura.click(function() {
            $(this).parents(".carta").remove();
        });

        //botó afegir carta al tapet
        $afegirCartaTapet.click(afegirCartaTapet);

        //botó moure carta a la dreta
        $opcions.children('span.fas.fa-arrow-left').click(function() {
            var $cartaMoure = $(this).parents(".carta");
            $($cartaMoure).insertBefore($($cartaMoure).prev($cartaMoure));
        })

        //botó moure a la dreta
        $opcions.children('span.fas.fa-arrow-right').click(function() {
            var $cartaMoure = $(this).parents(".carta");
            $($cartaMoure).insertAfter($($cartaMoure).next($cartaMoure));
        })

    })

});