$(function() {
    // Document is ready

    var exercici1 = function() {

        //inicialment les quatre icones ocultes
        $('#cartes-ma').find('.carta').each(function() {
            $(this).find('.opcions').hide();
        })

        //visibles l’usuari passi el ratolí per sobre de la carta
        $('#cartes-ma').find('.carta').each(function() {
            $(this).on("mouseover", function() {
                $(this).find('.opcions').show();
            })
        })

        //el ratolí surti d’aquesta carta, s’hauran de tornar a amagar
        $('#cartes-ma').find('.carta').each(function() {
            $(this).on("mouseleave", function() {
                $(this).find('.opcions').hide();
            })
        })
    }

    var exercici2 = function() {
        var cartes = document.getElementById('cartes-ma'), //partir de l'element amb id
            cubellBasura = cartes.getElementsByClassName('fas fa-trash-alt'); //HTMLCollection(5)

        //iterar per a afegir events a cada icona.   
        for (var i = 0; i < cubellBasura.length; i++) {
            cubellBasura[i].addEventListener("click", function() {
                this.parentNode.parentNode.parentNode.parentNode.remove();
            })
        }
    }

    var exercici3 = function() {
        $('#cartes-ma').find('.fas.fa-arrow-right').each(function() {
            $(this).on("click", function() {
                console.log($(this).parent().parent().parent().parent().insertAfter($(this).parent().parent().parent().parent().next())); // insertAfter next
            });
        })

        $('#cartes-ma').find('.fas.fa-arrow-left').each(function() {
            $(this).on("click", function() {
                console.log($(this).parent().parent().parent().parent().insertBefore($(this).parent().parent().parent().parent().prev())); //insertBefore prev
            });
        })
    }

    var exercici4 = function() {
        const placeholder = document.createElement('div');
        var html = "<div class=\"carta-jugada\" style=\"background-color:green\">" + "<span>Marwyn, the Nurturer</span>" + "<img src=\"https://c1.scryfall.com/file/scryfall-cards/art_crop/front/a/a/aad61d99-5c8e-47b7-ab1a-e70905f59205.jpg?1611966171\">" +
            "<p>" + "<span>1</span>" +
            "<span>1</span>" +
            " </p>";
        placeholder.innerHTML = html;
        var cartesTapet = document.getElementById('terreny-joc');
        exercici4Daus();

    }

    var exercici4Daus = function() {
        //afegir l'event als daus
        var cartes = document.getElementById('cartes-ma'), //partir de l'element amb id
            daus = cartes.getElementsByClassName('fas fa-dice'),
            cartesTapet = document.getElementById('terreny-joc'); //HTMLCollection(5)

        //iterar per a afegir events a cada icona.   
        for (var i = 0; i < daus.length; i++) {
            daus[i].addEventListener("click", function() {
                var color = this.parentNode.parentNode.parentNode.parentNode.getAttribute("color");
                var nom = this.parentNode.parentNode.getElementsByClassName("nom")[0].innerHTML;
                var imatge = this.parentNode.parentNode.getElementsByClassName("imatge-carta")[0].src;
                var power = this.parentNode.parentNode.getElementsByClassName("power")[0] == undefined ? null : this.parentNode.parentNode.getElementsByClassName("power")[0].innerHTML;
                var toughness = this.parentNode.parentNode.getElementsByClassName("toughness")[0] == undefined ? null : this.parentNode.parentNode.getElementsByClassName("toughness")[0].innerHTML;

                console.log(nom + " " + imatge + " " + power + " " + toughness);

                //passar estes dades a l'html

                //crear un div i afegirlo al costat de la carta del tapet
                var div = document.createElement("div");
                div.classList.toggle("carta-jugada");
                div.style = "background-color:" + color + ";"
                div.innerHTML = "<span>" + nom + " </span>" +
                    "<img src=" + imatge + ">" +
                    "<p> <span>" + power + "</span> / <span>" + toughness + "</span> </p> "

                cartesTapet.appendChild(div);

            })
        }
    }

    var exercici5 = function() {

        $("#formulari").prev().on("click", function() {
            $("#formulari").show();
        })

        $("#formulari").find(".btn.cancel").on("click", function() {
            $("#formulari").hide();
        })
    }

    var exercici6 = function() {
        $("#formulari").find(':submit').on("click", function(e) {
            e.preventDefault();
            var nom = $('input:text[name=nom]').val(),
                mana = $('input:text[name=mana]').val(),
                color = $("#color").attr("selected", true).val(),
                imatge = $('input:text[name=imat]').val(),
                tipus = $('input:text[name=tipus]').val(),
                descripcio = $('input:text[name=desc]').val(),
                mana = transformar_text($('#mana').val());

            console.log(nom + " " + mana + " " + color + " " +
                imatge + " " +
                tipus + " " + descripcio);

            //creació elements del DOM amb jquery    
            var $divPrincipal = $("<div>");
            $divPrincipal.addClass("carta");
            $divPrincipal.attr("color", color);
            var $divInterior = '<div class="fons-carta">' +

                '<div class="card-frame">' +
                '<div class="opcions">' +
                '<span class="fas fa-dice"></span>' +
                '<span class="fas fa-arrow-right"></span>' +
                '<span class="fas fa-arrow-left"></span>' +
                '<span class="fas fa-trash-alt"></span>' +
                '</div>' +

                '<div class="contingut-carta">' +
                '<h1 class="nom">' + nom + '</h1>' +
                '<div class="mana"><img src=' + "https://c2.scryfall.com/file/scryfall-symbols/card-symbols/5.svg" + ' class="mana-icon"><img src=' + "https://c2.scryfall.com/file/scryfall-symbols/card-symbols/G.svg" + ' class="mana-icon"></div>' +
                '</div>' +

                '<img class="imatge-carta" src=' + imatge + ' alt="nissa art">' +

                '<div class="tipus-carta">' +
                '<h1 class="type">' + tipus + '</h1>' +
                '</div> ' +

                '<div class="text-carta">' +
                '<p class="descripcio marge-intern">' + descripcio + '</p>' +
                '<p class="text-farciment">' + '</p>' +
                '</div>' +
                '</div>' +

                '</div>'
            $divPrincipal.append($divInterior);


            //afegir els events als botons
            $divPrincipal.find('.fa-trash-alt').on('click', function() {
                var $carta = $(this).parents('.carta')
                $carta.remove();
            });

            $divPrincipal.find('.fa-arrow-right').on('click', function() {
                var $carta = $(this).parents('.carta')
                $carta.insertAfter($carta.next());
            });

            $divPrincipal.find('.fa-arrow-left').on('click', function() {
                var $carta = $(this).parents('.carta')
                $carta.insertBefore($carta.prev());
            });




            //afegim la carta a la mà
            $("#cartes-ma").append($divPrincipal);

        })

    }



    exercici1();
    exercici2();
    exercici3();
    exercici4();
    exercici5();
    exercici6();
});

/*window.onload = function() {

    var exercici1 = function() {

        //inicialment les quatre icones ocultes
        $('#cartes-ma').find('.carta').each(function() {
            $(this).find('.opcions').hide();
        })

        //visibles l’usuari passi el ratolí per sobre de la carta
        $('#cartes-ma').find('.carta').each(function() {
            $(this).on("mouseover", function() {
                $(this).find('.opcions').show();
            })
        })

        //el ratolí surti d’aquesta carta, s’hauran de tornar a amagar
        $('#cartes-ma').find('.carta').each(function() {
            $(this).on("mouseleave", function() {
                $(this).find('.opcions').hide();
            })
        })
    }

    var exercici2 = function() {
        var cartes = document.getElementById('cartes-ma'), //partir de l'element amb id
            cubellBasura = cartes.getElementsByClassName('fas fa-trash-alt'); //HTMLCollection(5)

        //iterar per a afegir events a cada icona.   
        for (var i = 0; i < cubellBasura.length; i++) {
            cubellBasura[i].addEventListener("click", function() {
                this.parentNode.parentNode.parentNode.parentNode.remove();
            })
        }
    }

    var exercici3 = function() {
        $('#cartes-ma').find('.fas.fa-arrow-right').each(function() {
            $(this).on("click", function() {
                console.log($(this).parent().parent().parent().parent().insertAfter($(this).parent().parent().parent().parent().next())); // insertAfter next
            });
        })

        $('#cartes-ma').find('.fas.fa-arrow-left').each(function() {
            $(this).on("click", function() {
                console.log($(this).parent().parent().parent().parent().insertBefore($(this).parent().parent().parent().parent().prev())); //insertBefore prev
            });
        })
    }

    var exercici4 = function() {
        const placeholder = document.createElement('div');
        var html = "<div class=\"carta-jugada\" style=\"background-color:green\">" + "<span>Marwyn, the Nurturer</span>" + "<img src=\"https://c1.scryfall.com/file/scryfall-cards/art_crop/front/a/a/aad61d99-5c8e-47b7-ab1a-e70905f59205.jpg?1611966171\">" +
            "<p>" + "<span>1</span>" +
            "<span>1</span>" +
            " </p>";
        placeholder.innerHTML = html;
        var cartesTapet = document.getElementById('terreny-joc');
        exercici4Daus();

    }

    var exercici4Daus = function() {
        //afegir l'event als daus
        var cartes = document.getElementById('cartes-ma'), //partir de l'element amb id
            daus = cartes.getElementsByClassName('fas fa-dice'),
            cartesTapet = document.getElementById('terreny-joc'); //HTMLCollection(5)

        //iterar per a afegir events a cada icona.   
        for (var i = 0; i < daus.length; i++) {
            daus[i].addEventListener("click", function() {
                var color = this.parentNode.parentNode.parentNode.parentNode.getAttribute("color");
                var nom = this.parentNode.parentNode.getElementsByClassName("nom")[0].innerHTML;
                var imatge = this.parentNode.parentNode.getElementsByClassName("imatge-carta")[0].src;
                var power = this.parentNode.parentNode.getElementsByClassName("power")[0] == undefined ? null : this.parentNode.parentNode.getElementsByClassName("power")[0].innerHTML;
                var toughness = this.parentNode.parentNode.getElementsByClassName("toughness")[0] == undefined ? null : this.parentNode.parentNode.getElementsByClassName("toughness")[0].innerHTML;

                console.log(nom + " " + imatge + " " + power + " " + toughness);

                //passar estes dades a l'html

                //crear un div i afegirlo al costat de la carta del tapet
                var div = document.createElement("div");
                div.classList.toggle("carta-jugada");
                div.style = "background-color:" + color + ";"
                div.innerHTML = "<span>" + nom + " </span>" +
                    "<img src=" + imatge + ">" +
                    "<p> <span>" + power + "</span> / <span>" + toughness + "</span> </p> "

                cartesTapet.appendChild(div);

            })
        }
    }

    var exercici5 = function() {

        $("#formulari").prev().on("click", function() {
            $("#formulari").show();
        })

        $("#formulari").find(".btn.cancel").on("click", function() {
            $("#formulari").hide();
        })
    }

    var exercici6 = function() {
        $("#formulari").find(':submit').on("click", function() {
            var nom = $('input:text[name=nom]').val(),
                mana = $('input:text[name=mana]').val(),
                color = $("#color").attr("selected", true).val(),
                imatge = $('input:text[name=imat]').val(),
                tipus = $('input:text[name=tipus]').val(),
                descripcio = $('input:text[name=desc]').val();

            console.log(nom + " " + mana + " " + color + " " +
                imatge + " " +
                tipus + " " + descripcio);
        })



    }



    exercici1();
    exercici2();
    exercici3();
    exercici4();
    exercici5();
    exercici6();





}*/

function transformar_text(text_simbols) {
    //Convertim els salts de línia a format HTML
    text_transformat = text_simbols.replace(/\r?\n/g, "<br />");
    //Cerquem el text a transformar
    var trobar = /\{[A-Z0-9/]*\}/g;
    //Canviem el text per les imatges corresponents
    var text_transformat = text_transformat.replace(trobar, function(x) {
        //Afagem el text de dintre de les {} treient les / interiors (si hi ha alguna)
        var lletres = x.substring(1, x.length - 1).replace('/', '');
        return "<img src='https://c2.scryfall.com/file/scryfall-symbols/card-symbols/" + lletres + ".svg' class='mana-icon'>"
    });
    return text_transformat;
}